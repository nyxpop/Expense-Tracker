// Middleware untuk memeriksa apakah user sudah login
const requireAuth = (req, res, next) => {
  if (req.session && req.session.userId) {
    next();
  } else {
    res.status(401).json({ 
      message: 'Unauthorized: Please login first' 
    });
  }
};

// Middleware untuk memeriksa jika user sudah login
const redirectIfLoggedIn = (req, res, next) => {
  if (req.session && req.session.userId) {
    return res.status(200).json({ 
      message: 'Already logged in',
      user: req.session.user
    });
  }
  next();
};

// Middleware untuk mendapatkan user data jika logged in
const getCurrentUser = (req, res, next) => {
  if (req.session && req.session.userId) {
    req.currentUser = req.session.user;
  }
  next();
};

module.exports = { 
  requireAuth, 
  redirectIfLoggedIn, 
  getCurrentUser 
};