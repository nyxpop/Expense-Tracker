const express = require('express');
const router = express.Router();

// Middleware to check if user is authenticated
const isAuthenticated = (req, res, next) => {
  if (req.session && req.session.userId) {
    next();
  } else {
    res.status(401).json({ message: 'Unauthorized' });
  }
};

// GET all expenses for authenticated user
router.get('/', isAuthenticated, (req, res) => {
  res.json({ message: 'Get all expenses', userId: req.session.userId });
});

// POST create a new expense
router.post('/', isAuthenticated, (req, res) => {
  const { description, amount, category, date } = req.body;
  res.status(201).json({ 
    message: 'Expense created', 
    data: { description, amount, category, date, userId: req.session.userId } 
  });
});

// GET expense by ID
router.get('/:id', isAuthenticated, (req, res) => {
  res.json({ message: `Get expense ${req.params.id}`, userId: req.session.userId });
});

// PUT update expense
router.put('/:id', isAuthenticated, (req, res) => {
  res.json({ message: `Update expense ${req.params.id}`, userId: req.session.userId });
});

// DELETE expense
router.delete('/:id', isAuthenticated, (req, res) => {
  res.json({ message: `Delete expense ${req.params.id}`, userId: req.session.userId });
});

module.exports = router;