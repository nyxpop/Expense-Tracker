const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('../config/database');
const { requireAuth, redirectIfLoggedIn, getCurrentUser } = require('../middleware/auth');
const router = express.Router();

// Check auth status
router.get('/status', getCurrentUser, (req, res) => {
  if (req.currentUser) {
    res.json({ 
      loggedIn: true, 
      user: req.currentUser 
    });
  } else {
    res.json({ loggedIn: false });
  }
});

// Register
router.post('/register', redirectIfLoggedIn, async (req, res) => {
  try {
    const { username, email, password } = req.body;

    if (!username || !email || !password) {
      return res.status(400).json({ message: 'All fields are required' });
    }

    if (password.length < 6) {
      return res.status(400).json({ message: 'Password must be at least 6 characters' });
    }

    const checkUserQuery = 'SELECT * FROM users WHERE email = ? OR username = ?';
    db.query(checkUserQuery, [email, username], async (err, results) => {
      if (err) return res.status(500).json({ error: err.message });
      if (results.length > 0) {
        return res.status(400).json({ message: 'User already exists' });
      }

      const hashedPassword = await bcrypt.hash(password, 12);

      const insertQuery = 'INSERT INTO users (username, email, password) VALUES (?, ?, ?)';
      db.query(insertQuery, [username, email, hashedPassword], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        
        req.session.userId = results.insertId;
        req.session.user = {
          id: results.insertId,
          username: username,
          email: email
        };

        res.status(201).json({
          message: 'User registered successfully',
          user: req.session.user
        });
      });
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Login
router.post('/login', redirectIfLoggedIn, (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ message: 'Email and password are required' });
    }

    const query = 'SELECT * FROM users WHERE email = ?';
    db.query(query, [email], async (err, results) => {
      if (err) return res.status(500).json({ error: err.message });
      if (results.length === 0) {
        return res.status(401).json({ message: 'Invalid credentials' });
      }

      const user = results[0];
      const isValidPassword = await bcrypt.compare(password, user.password);

      if (!isValidPassword) {
        return res.status(401).json({ message: 'Invalid credentials' });
      }

      req.session.userId = user.id;
      req.session.user = {
        id: user.id,
        username: user.username,
        email: user.email
      };

      res.json({
        message: 'Login successful',
        user: req.session.user
      });
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Logout
router.post('/logout', requireAuth, (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      return res.status(500).json({ error: 'Could not log out' });
    }
    
    res.clearCookie('user_sid');
    res.json({ message: 'Logout successful' });
  });
});

// Get current user profile
router.get('/profile', requireAuth, (req, res) => {
  res.json({ user: req.session.user });
});

module.exports = router;