const session = require('express-session');
const MySQLStore = require('express-mysql-session')(session);
const db = require('../config/database');

const sessionStore = new MySQLStore({
  expiration: 86400000, // 1 hari
  createDatabaseTable: true,
  schema: {
    tableName: 'user_sessions',
    columnNames: {
      session_id: 'session_id',
      expires: 'expires',
      data: 'data'
    }
  }
}, db);

const sessionMiddleware = session({
  key: 'user_sid',
  secret: process.env.SESSION_SECRET,
  store: sessionStore,
  resave: false,
  saveUninitialized: false,
  cookie: {
    maxAge: 24 * 60 * 60 * 1000, // 1 hari
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production'
  }
});

module.exports = sessionMiddleware;